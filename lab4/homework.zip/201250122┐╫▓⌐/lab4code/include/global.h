
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                            global.h
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                                                    Forrest Yu, 2005
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/* EXTERN is defined as extern except in global.c */
#ifdef	GLOBAL_VARIABLES_HERE
#undef	EXTERN
#define	EXTERN
#endif

EXTERN	int		ticks;

EXTERN	int		disp_pos;
EXTERN	u8		gdt_ptr[6];	// 0~15:Limit  16~47:Base
EXTERN	DESCRIPTOR	gdt[GDT_SIZE];
EXTERN	u8		idt_ptr[6];	// 0~15:Limit  16~47:Base
EXTERN	GATE		idt[IDT_SIZE];

EXTERN	u32		k_reenter;

EXTERN	TSS		tss;
EXTERN	PROCESS*	p_proc_ready; //这个进程指的是队首最先准备好了的进程吗?????????

extern	PROCESS		proc_table[]; //进程表
extern	char		task_stack[];
extern  TASK            task_table[];
extern	irq_handler	irq_table[];


/*====================================================================================
 *                 new add 资源处理
 =====================================================================================*/
//信号量
typedef struct semaphore{
    int value; //还资源有几个，默认一个
    int head;
    int tail; //队首 队尾
    PROCESS* queue[NR_TASKS]; //排队等待使用该资源的进程
//    PROCESS* currentPros[NR_TASKS]; //当前正在执行的进程有哪些 分别对应六个进程（每个进程放的位置的下标固定，不可变）
//    int isBeingWritten=0; //是否有人正在写 0:无人在写
}Semaphore;

EXTERN int readingCounters;//此时正有几个读者真正在读
EXTERN int maxReaderCount; //同时最多允许几个读者
EXTERN int currentReaderCount;// 当前有几个读者准备在读=0
EXTERN int currentWriterCount;//当前有几个写者=0
EXTERN Semaphore rwMutex;//文件资源 用于writer first，reader first，公平读写 {1,0,-1}
EXTERN Semaphore readerCounterMutex;//共享当前读者数 用于writer first，reader first，公平读写={1,0,-1}
EXTERN Semaphore blockReaderMutex;//用于阻止reader进入的锁 用于writer first，公平读写  相当于共享一个boolean变量，该变量代表的是此时是否有写进程在工作={1,0,-1}
EXTERN Semaphore writerCounterMutex;//共享当前写者数 用于writer first={1,0,-1}
EXTERN Semaphore maxReaderMutex;//用于控制同时读的读着数 {maxReaderCount,0,-1}

/*============================================================================
 *       new add: 策略选项
 ==============================================================================*/
PUBLIC int strategy; // 0: reader first 1: writer first  2:fair


PUBLIC int color;//全局变量 用于存放当前想打印什么颜色


PUBLIC int state[5]; //每次实时更新
PUBLIC int index;//指向快照轮次的指针（与state配合使用）
PUBLIC int judge;
PUBLIC int isReadyToPrint[5];