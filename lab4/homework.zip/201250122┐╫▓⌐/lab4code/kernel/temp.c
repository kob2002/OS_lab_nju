//
// Created by 十甫寸 on 2022/12/12.
//

//7.1
struct Record{
    string name;
    int seatNum;
};
semaphore rwMutex=1,counter=100; //读写锁，座位数锁
Record seats[100]={null};


void reader(string name){
    //先拿到座位的数量
    int i=0;//记录座位号
    P(counter);
    V(counter);
    P(rwMutex);
    for(i=0;i<100;i++){
        if(seats[i]==null) {
            seats[i].name=name;//写入登记者的名字
            break;
        }
    }
    V(rwMutex);

    sitDown();
    read();

    P(rwMutex);
    seats[i]=null;
    V(rwMutex);
    V(counter);

};


//7.2
struct Record{
    string name;
    int seatNum;
};
type library= MONTOR{
    semaphore isAvailable;//
    int availableCounter=0;//等待信号量的数目
    int seatCounter=0;//已占用了的座位数
    Record seats[100]={null};


};
InterfaceModule IM; //管程

int logIn(string name){
    int seatNum=0;
    enter(IM);
    if(seatCounter>100) wait(isAvailable,availableCounter,IM);
    seatCounter++;
    for(int i=0;i<100;i++){  //登记名字
        if(seats[i]==null){
            seats[i].name=name;
            seatNum=i;
            break;
        }
    }

    sitDown();
    read();
    leave(IM);
    return seatNum;
}

void logOut(int seatNum){
    enter(IM);
    seatCounter--;
    seats[seatNum]=null;//归还
    signal(isAvailable,availableCounter,IM);
    leave(IM);
}


void reader(string name){
    int seatNum=library.logIn(name);
    library.logOut(seatNum);
}

//8.1

semaphore black=0,white=1;

void BlackPicker(){
    while (1){
        P(white);
        pick(black);
        V(black);
    }
}

void WhitePicker(){
    while (1){
        P(black);
        pick(white);
        V(white);
    }
}

//8.2
type picker=MONTOR{
    semaphore blackPicker,whitePicker;
    int blackCounter=0,whiteCounter;//等待信号量的进程数量
    int box=1;

};
InterfaceModule IM; //管程
void bPicker(){
    enter(IM);
    if(box==0) wait(blackPicker,blackCounter,IM);
    box=0;
    //picking……

    signal(blackPicker,blackCounter,IM);
    leave(IM);
}

void wPicker(){
    enter(IM);
    if(box==1) wait(whitePicker,whiteCounter,IM);
    box=1;
    //picking……
    signal(whitePicker,whiteCounter,IM);
    leave(IM);
}

void pickBlack(){
    while(1){
        bPicker();
    }
}

void pickWhite(){
    while (1){
        wPicker();
    }
}


//9.1

semaphore inputArea=1,outputArea=0,inputerMutex=1,outputerMutex=1;//inputArea:与counter配合使用，虽然
// value为1，但是表达三个缓冲区的空与否后两个：控制生产者间、消费者间的互斥
int area[9]={-1};
int counter=0;//用于记录缓冲区拿空了几个
int num[3];
void inputer(){
    while (1){
        P(inputArea);
        P(inputerMutex);

        //将产生的三个数放在num数组中

        for(int i=0;i<3;i++){
            int index=0;
            while (area[index]!=-1){
                index++;
            }
            area[index]=num[i];
        }//写入对应的缓冲区

        V(inputerMutex);

        V(outputArea);
        V(outputArea);
        V(outputArea);
    }



}

void outputer(){
    while (1){
        P(outputArea);
        P(outputerMutex);
        int i=0;
        for(i=0;i<9;i++){
            if(area[i]==1) break;
        }
        //取出i的缓冲区内容
        counter++;
        if(counter==3){
            count=0;
            V(inputArea);
        }

        V(outputerMutex);

    }


}

//9.2

type buffer =MONITOR{
    semaphore inputArea=1,outputArea=1;
    int inputAreaWaiterCounter=0,outputAreaWaiterCounter=0;
    int area[9]={-1};
    int counter=0;//当前被占用的缓存区数目

};
InterfaceModule IM; //管程

void input(int a,int b,int c){
    int num[3]={a,b,c};
    enter(IM);
    if(counter>6) wait(inputArea,inputAreaWaiterCounter,IM);
    counter+=3;
    for(int i=0;i<3;i++){
        int index=0;
        while (area[index]!=-1){
            index++;
        }
        area[index]=num[i];
    }//找到三个空地存放整数
    signal(outputArea,outputAreaWaiterCounter,IM);
    signal(outputArea,outputAreaWaiterCounter,IM);
    signal(outputArea,outputAreaWaiterCounter,IM);

    leave(IM);
}

int outPut(){
    int outInteger;
    enter(IM);
    if(counter==0) wait(outputArea,outputAreaWaiterCounter,IM);//缓冲区没东西
    counter--;
    for(int i=0;i<9;i++){
        if(area[i]!=-1){
            outInteger=area[i];
            break;
        }
    }
    if(counter<=6){//说明有空余区
        V(inputArea,inputAreaWaiterCounter,IM);
    }
    leave(IM);
    return outInteger;
}


void inputer(){
    int a,int b,int c;
    while (1){
        produce();//生产三个数,存入a,b,c中
        input(a,b,c);
    }

}

void outputer(){
    int outChar=outPut();
}



//6.1

semaphore M0=1,M1=1,M2=1,M3=1; //用于信箱内部加锁
semaphore empty0=0,empty1=3,empty2=2,empty3=2;
semaphore letter0=3,letter1=3,letter2=2,letter3=2;
int head0=0,head1=0,head2=0,head3=0;//分别是指向四个信箱内部可以取的位置
int tail0=2,tail1=-1,tail2=-1,tail3=-1;//执行队列的尾部 刚开始没有 置为-1

void p0(){
    while (1){
        P(letter0);
        P(M0);
        fetch(head0);
        head0=(head0+1)%3;//后移头部
        V(M0);
        V(letter0);

        //sending

        P(letter1);
        P(M1);
        tail1=(tail1+1)%3;//先找到空地
        send(tail1);
        V(M1);
        V(letter1);

    }
}

void P1(){
    while (1){
        P(letter1);
        P(M1);
        fetch(head1);
        head1=(head1+1)%3;
        V(M1);
        V(letter1);

        //sending

        P(letter1);
        P(M1);
        tail2=(tail2+1)%3;//先找到空地
        send(tail2);
        V(M1);
        V(letter1);

    }
}

void P2(){
    while (1){
        P(letter2);
        P(M2);
        fetch(head2);
        head2=(head2+1)%3;
        V(M2);
        V(letter2);

        //sending

        P(letter2);
        P(M2);
        tail3=(tail3+1)%2;//先找到空地
        send(tail3);
        V(M2);
        V(letter2);

    }
}

void P3(){
    while (1){
        P(letter3);
        P(M3);
        fetch(head3);
        head3=(head3+1)%3;
        V(M3);
        V(letter3);

        //sending

        P(letter3);
        P(M3);
        tail0=(tail0+1)%3;//先找到空地
        send(tail0);
        V(M3);
        V(letter3);

    }
}



