
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                            global.c
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                                                    Forrest Yu, 2005
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#define GLOBAL_VARIABLES_HERE

#include "type.h"
#include "const.h"
#include "protect.h"
#include "proto.h"
#include "proc.h"
#include "global.h"


PUBLIC	PROCESS			proc_table[NR_TASKS];  //进程表

PUBLIC	char			task_stack[STACK_SIZE_TOTAL];

PUBLIC	TASK	task_table[NR_TASKS] = {{TaskA, STACK_SIZE_TESTA, "TaskA"},
					{TaskB, STACK_SIZE_TESTB, "TaskB"},
					{TaskC, STACK_SIZE_TESTC, "TaskC"},
                    {TaskD, STACK_SIZE_TESTC, "TaskD"},
                    {TaskE, STACK_SIZE_TESTC, "TaskE"},
                    {TaskF, STACK_SIZE_TESTC, "TaskF"}}; //add D E F

PUBLIC	irq_handler		irq_table[NR_IRQ];

PUBLIC	system_call		sys_call_table[NR_SYS_CALL] = {sys_get_ticks,
                                                        sys_print,
                                                        sys_sleep,
                                                        sys_p,
                                                        sys_v}; //add new system_call 对应syscall.asm中的方法

