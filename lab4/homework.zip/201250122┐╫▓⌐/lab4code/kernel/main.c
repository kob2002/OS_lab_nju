
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                            main.c
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                                                    Forrest Yu, 2005
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include "type.h"
#include "const.h"
#include "protect.h"
#include "proto.h"
#include "string.h"
#include "proc.h"
#include "global.h"



/*======================================================================*
                            kernel_main
 *======================================================================*/

PUBLIC int kernel_main()
{
	disp_str("-----\"kernel_main\" begins-----\n");

	TASK*		p_task		= task_table;
	PROCESS*	p_proc		= proc_table;
	char*		p_task_stack	= task_stack + STACK_SIZE_TOTAL;
	u16		selector_ldt	= SELECTOR_LDT_FIRST;
	int i;
	for (i = 0; i < NR_TASKS; i++) {
		strcpy(p_proc->p_name, p_task->name);	// name of the process
		p_proc->pid = i;			// pid
        //这里是进程的初始化！！！！！！！！！

		p_proc->ldt_sel = selector_ldt;

		memcpy(&p_proc->ldts[0], &gdt[SELECTOR_KERNEL_CS >> 3],
		       sizeof(DESCRIPTOR));
		p_proc->ldts[0].attr1 = DA_C | PRIVILEGE_TASK << 5;
		memcpy(&p_proc->ldts[1], &gdt[SELECTOR_KERNEL_DS >> 3],
		       sizeof(DESCRIPTOR));
		p_proc->ldts[1].attr1 = DA_DRW | PRIVILEGE_TASK << 5;
		p_proc->regs.cs	= ((8 * 0) & SA_RPL_MASK & SA_TI_MASK)
			| SA_TIL | RPL_TASK;
		p_proc->regs.ds	= ((8 * 1) & SA_RPL_MASK & SA_TI_MASK)
			| SA_TIL | RPL_TASK;
		p_proc->regs.es	= ((8 * 1) & SA_RPL_MASK & SA_TI_MASK)
			| SA_TIL | RPL_TASK;
		p_proc->regs.fs	= ((8 * 1) & SA_RPL_MASK & SA_TI_MASK)
			| SA_TIL | RPL_TASK;
		p_proc->regs.ss	= ((8 * 1) & SA_RPL_MASK & SA_TI_MASK)
			| SA_TIL | RPL_TASK;
		p_proc->regs.gs	= (SELECTOR_KERNEL_GS & SA_RPL_MASK)
			| RPL_TASK;

		p_proc->regs.eip = (u32)p_task->initial_eip;
		p_proc->regs.esp = (u32)p_task_stack;
		p_proc->regs.eflags = 0x1202; /* IF=1, IOPL=1 */

		p_task_stack -= p_task->stacksize;
		p_proc++;
		p_task++;
		selector_ldt += 1 << 3;
	}


    /*===============================================================================
     *                这里要初始化信号量 选择策略
     ==============================================================================*/
    readingCounters=0;
    maxReaderCount=3; //同时最多允许几个读者
    maxReaderMutex.value=3;
    strategy=0;
    currentReaderCount=0;// 当前有几个读者在读
    currentWriterCount=0;//当前有几个写者
    rwMutex.value=1;
    rwMutex.head=0;
    rwMutex.tail=-1;//文件资源 用于writer first，reader first，公平读写
    readerCounterMutex.value=1;
    readerCounterMutex.head=0;
    readerCounterMutex.tail=-1;//共享当前读者数 用于writer first，reader first，公平读写
    blockReaderMutex.value=1;
    blockReaderMutex.head=0;
    blockReaderMutex.tail=-1;//用于阻止reader进入的锁 用于writer first，公平读写  相当于共享一个boolean变量，该变量代表的是此时是否有写进程在工作
    writerCounterMutex.value=1;
    writerCounterMutex.head=0;
    writerCounterMutex.tail=-1;//共享当前写者数 用于writer first
    maxReaderMutex.head=0;
    maxReaderMutex.tail=-1;//用于控制同时读的读着数 {maxReaderCount,0,-1}
/*============================================================================================================
 *     定义不同进程的休息时间和工作时间
 ===========================================================================================================*/

    proc_table[0].timeNeeded=0;
    proc_table[0].restTime=1;//A 进程在1个时间片内不能被分配时间片
    proc_table[0].blocked=0;
    proc_table[0].wake=0;
    proc_table[0].workTimeLeft=0;
    proc_table[0].sleepTimeLeft=0;
    proc_table[0].taskNumber=0;

    proc_table[1].timeNeeded=2;
    proc_table[1].restTime=2;
    proc_table[1].blocked=0;
    proc_table[1].wake=0;
    proc_table[1].workTimeLeft=0;
    proc_table[1].sleepTimeLeft=0;
    proc_table[1].taskNumber=0;

    proc_table[2].timeNeeded=3;
    proc_table[2].restTime=3;
    proc_table[2].blocked=0;
    proc_table[2].wake=0;
    proc_table[2].workTimeLeft=0;
    proc_table[2].sleepTimeLeft=0;
    proc_table[2].taskNumber=0;

    proc_table[3].timeNeeded=3;
    proc_table[3].restTime=3;
    proc_table[3].blocked=0;
    proc_table[3].wake=0;
    proc_table[3].workTimeLeft=0;
    proc_table[3].sleepTimeLeft=0;
    proc_table[3].taskNumber=0;

    proc_table[4].timeNeeded=3;
    proc_table[4].restTime=2;
    proc_table[4].blocked=0;
    proc_table[4].wake=0;
    proc_table[4].workTimeLeft=0;
    proc_table[4].sleepTimeLeft=0;
    proc_table[4].taskNumber=0;

    proc_table[5].timeNeeded=4;
    proc_table[5].restTime=1;
    proc_table[5].blocked=0;
    proc_table[5].wake=0;
    proc_table[5].workTimeLeft=0;
    proc_table[5].sleepTimeLeft=0;
    proc_table[5].taskNumber=0;

	k_reenter = 0;
	ticks = 0;

    index=0;
    judge=0;

	p_proc_ready	= proc_table; //先调用打印进程

        /* 初始化 8253 PIT */
        out_byte(TIMER_MODE, RATE_GENERATOR);
        out_byte(TIMER0, (u8) (TIMER_FREQ/HZ) );
        out_byte(TIMER0, (u8) ((TIMER_FREQ/HZ) >> 8));

        put_irq_handler(CLOCK_IRQ, clock_handler); /* 设定时钟中断处理程序 */
        enable_irq(CLOCK_IRQ);                     /* 让8259A可以接收时钟中断 */
        //disable_irq(CLOCK_IRQ);

    for(int i=0;i<5;i++){
        isReadyToPrint[i]=0;
    }


	restart();

	while(1){}
}


/*========================================================================================
 *                     new add: 读者在读的时候要改变自己的状态 读完也要改变自己的状态 休息结束 和休息
 =======================================================================================*/
/**
 * 进入工作状态（包括读和写） 正常来说 进入这个方法的进程应当是blocked=0 current ticks>=wake的 即清醒的
 */
void work(PROCESS* process){

    //工作一个时间段  如果没有在休眠 也没有被堵塞 则认为是在工作 可能有问题
    process->workTimeLeft=(process->timeNeeded);
   // disp_str("work=");
//    disp_str(transIntToCharArr(p_proc_ready->workTimeLeft));
    schedule();
    //milli_delay(10);//废除当前时间片

   // milli_delay(TIME_SLICE*(process->timeNeeded));//这里要强制给予时间片  TIME_SLICE




}


/**
 * 结束工作 进入休息状态
 */
void endWork(PROCESS* process){

    //修正醒来时间
    process->sleepTimeLeft=(process->restTime);
    //disp_str("rest=");
    schedule();
    //milli_delay(10);//废除当前时间片
    //休息一段时间

    //mySleep((process->restTime)*TIME_SLICE);




}

int strcmp(char* s1,int l1,char* s2,int l2){
    for(int i=0;i<l1;i++){
        if(i>=l2) return -1;
        if(s1[i]==s2[i]&&s1[i]=='\0') return 0;
        if(s1[i]!=s2[i]) return -1;
    }
    return 0;
}


/**
 * 根据传入的名字找到对应的进程
 * @param name
 * @return
 */
PROCESS* findProcessInProcTable(char name[16]){ //proc_table

    for(int i=0;i<NR_TASKS;i++){
        PROCESS pro=proc_table[i];
        if(strcmp(pro.p_name,16,name,16)==0) return &pro;

    }
    char warning[]="No such process!\n";
    color=1;
    //myPrint(warning);
    return proc_table;
}

/*===================================================================
 *                 读者优先
 ===================================================================*/
/**
 * reader first 读者进程
 */
void rf_reader(PROCESS* process){
    //disp_str(process->p_name);
    P(&readerCounterMutex); //因为要取正在读的数 所以要给counter上锁
    currentReaderCount++;
    if(currentReaderCount==1){
        //说明当前进程是第一个读者
        P(&rwMutex); //与写进程互斥（这里不会禁止其他读进程）
    }
    V(&readerCounterMutex);


    P(&maxReaderMutex);//读者并发上锁 防止超过了最大读并发数
    // reading...... 消耗时间片
//    process->workTimeLeft=(process->timeNeeded);
//    schedule();
    work(process);

    V(&maxReaderMutex);
    //process->sleepTimeLeft=(process->restTime);

    P(&readerCounterMutex);
    currentReaderCount--;
    if(currentReaderCount==0){
        //说明当前进程是最后一个读者
        //myPrint("");
        V(&rwMutex);
    }
    V(&readerCounterMutex);

    //schedule();
    endWork(process);
    //milli_delay(TIME_SLICE);//消耗掉这次的时间片

}

/**
 * reader first 写者进程
 */
void rf_writer(PROCESS* process){
    //disp_str(process->p_name);
    P(&rwMutex);//申请文件访问权限

    //writing......
    work(process);

    //myPrint("");
    V(&rwMutex);

    //mySleep(1);

    endWork(process);

    //milli_delay(TIME_SLICE); //消耗掉这次的时间片

}


/*===================================================================
 *                 写者优先
 ===================================================================*/

/**
 * writer first 读者进程
 */
void wf_reader(PROCESS* process){ //和reader first不一样的点在于在reader进行获取资源之前，还需过一道锁：blockReaderMutex，这道锁是writer上的，用于强调writer的优先级
    P(&blockReaderMutex); // 由于优先级低，所以必须经过没有写进程等待的判断

    P(&readerCounterMutex);
    currentReaderCount++;
    if(currentReaderCount==1){
        //说明当前进程是第一个读者
        P(&rwMutex);
    }
    V(&readerCounterMutex);

    V(&blockReaderMutex);//不能在最后释放 否则其他读进程会无法和他一起读

    P(&maxReaderMutex);


    // reading......
    work(process);

    V(&maxReaderMutex); //控制同时读的个数

    P(&readerCounterMutex);
    currentReaderCount--;
    if(currentReaderCount==0){
        //说明当前进程是最后一个读者
        V(&rwMutex);
    }
    V(&readerCounterMutex);




}

/**
 * reader first 写者进程
 */
void wf_writer(PROCESS* process){
    P(&writerCounterMutex);
    currentWriterCount++;
    if(currentWriterCount==1){
        //说明是第一个写者(即从此开始，需要进行对读者的屏蔽直至没有写进程的存在) 需要屏蔽所有的读者
        P(&blockReaderMutex);
    }
    V(&writerCounterMutex);

    P(&rwMutex);  //开始访问文件 屏蔽所有的进程（由于前面已经屏蔽了reader，这里屏蔽的是其他的writer)

    //writing......
    work(process);


    V(&rwMutex);
    P(&writerCounterMutex);
    currentWriterCount--;
    if(currentWriterCount==0){ //说明是最后一个写进程,从此开始对reader开放
        V(&blockReaderMutex);
    }
    V(&writerCounterMutex);
}







/*===================================================================
 *                 读写公平
 ===================================================================*/

/**
 * fair 读者进程
 */
void fair_reader(PROCESS* process){
    P(&blockReaderMutex);

    P(&readerCounterMutex);
    currentReaderCount++;
    if(currentReaderCount==1){ //读进程需要不能该其他读进程加锁 判断是用于不给不改加锁的进程加锁的
        //说明当前进程是第一个读者
        P(&rwMutex);
    }
    V(&readerCounterMutex);

    V(&blockReaderMutex);//不能在最后释放 否则其他读进程会无法和他一起读
    P(&maxReaderMutex);

    // reading......
    work(process);

    V(&maxReaderMutex);

    P(&readerCounterMutex);
    currentReaderCount--;
    if(currentReaderCount==0){
        //说明当前进程是最后一个读者
        V(&rwMutex);
    }
    V(&readerCounterMutex);

}
/**
 * fair 写者进程
 */
void fair_writer(PROCESS* process){

    P(&blockReaderMutex);//这个名字没有起好》》  由于公平读写了 所以不可以只给reader加锁 还要给writer加锁

    P(&rwMutex);


    //writing......
    work(process);

    V(&rwMutex);

    P(&blockReaderMutex);

}


char* strncat (char *s1,int l1, const char *s2,int l2)
{
    int endOfS1=0,endOfS2=0;
    for(;endOfS1<l1;endOfS1++){
        if(s1[endOfS1]=='\0') break;
    }
    for(;endOfS2<l2;endOfS2++){
        if(s2[endOfS2]=='\0') break;
    }
    for(int i=0;i<endOfS2;i++){
        s1[i+endOfS1]=s2[i];
    }
    s1[endOfS1+endOfS2]='\0';
    return s1;
}

/*=====================================================================
 *                new add: 判断进程的状态 0：休息 1：等待 2：正在运行 (由于进程处于一直执行的状态，所以不存在做完了这种情况)
 ====================================================================*/

PUBLIC int getProcessState(PROCESS* p){
    if(p->workTimeLeft>0) return 2;//正在工作
    if(p->sleepTimeLeft>0) return 0; //还未醒
    else if(p->blocked==1) return 1; //被阻塞 在等待
    return 0;

}

/*=========================================================================================
 *                      new add:Task A  输出进程
 ========================================================================================*/


void TaskA(){
    //先延迟半个时间片再打印(保证其他进程把该改的都改了)
    //清屏 竟然要花掉两个时间片

      disp_pos = 0;
      for(int i=0;i<80*25;i++){
          disp_str("   ");
      }
      disp_pos = 0;


//    proc_table[0].sleepTimeLeft=1;//睡一个时间片
//    schedule();


    for(int i=0;i<22;i++){//打印20次
        //disp_str("Enter Print!");
//======================================输出序号
        char outputInfo[10];//要打印的信息
        if(i>=20){
            outputInfo[0]='2';
            outputInfo[1]=i-20+'0';
            outputInfo[2]='\0';
        }
        else if(i>=10){
            outputInfo[0]='1';
            outputInfo[1]=i-10+'0';
            outputInfo[2]='\0';
        }else{
            outputInfo[0]=i+'0';
            outputInfo[1]=' ';
            outputInfo[2]='\0';
        }
        //disp_str("!");
        color=1;
        myPrint(outputInfo); //输出序号
//=====================================结束输出序号

//输出五个状态
        //disp_str("!");
        for(int k=1;k<6;k++){
            int currentState= getProcessState(&proc_table[k]);
            if(currentState==0){
                color=2;
                myPrint(" Z");
            }else if(currentState==1){
                color=3;
                myPrint(" X");
            }else{
                color=4;
                myPrint(" O");

            }
        }
        color=1;
        myPrint("\n");//打印换行符
        //时间推进
        for(int j=0;j<NR_TASKS;j++){
            if(proc_table[j].workTimeLeft>0) {
                //disp_str("minus");
                proc_table[j].workTimeLeft--;
            }
            if(proc_table[j].sleepTimeLeft>0){
                //disp_str("minus");
                proc_table[j].sleepTimeLeft--;
            }
        }

        //mySleep(TIME_SLICE);//打印一次后 一个时间片内不允许分到其他时间片
        //proc_table[0].sleepTimeLeft=1;//睡一个时间片
        //disp_str("print=");
        schedule();
        //milli_delay(TIME_SLICE);//耗一个时间片
    }

    while(1){

    }

}







/*=======================================================================================
 *                        new add Task B reader 消耗2个时间⽚
 =======================================================================================*/
void TaskB(){
    PROCESS* process= &proc_table[1];
    while (1){
        //color=1;
        //myPrint("Bsleep! ");
        switch (strategy) {
            case 0:
                rf_reader(process);
                break;
            case 1:
                wf_reader(process);
                break;
            case 2:
                fair_reader(process);
                break;
        }

    }
}


/*=======================================================================================
 *                        new add Task C reader 消耗3个时间⽚
 =======================================================================================*/

void TaskC(){
    PROCESS* process= &proc_table[2];
    while (1){
        switch (strategy) {
            case 0:
                rf_reader(process);
                break;
            case 1:
                wf_reader(process);
                break;
            case 2:
                fair_reader(process);
                break;
        }

    }

}
/*=======================================================================================
 *                        new add Task D reader 消耗3个时间⽚
 =======================================================================================*/
void TaskD(){
    PROCESS* process= &proc_table[3];


    while (1){
//        color=1;
//        myPrint("Dwork! ");
        switch (strategy) {
            case 0:
                rf_reader(process);
                break;
            case 1:
                wf_reader(process);
                break;
            case 2:
                fair_reader(process);
                break;
        }

    }
}

/*=======================================================================================
 *                        new add Task E writer 消耗3个时间⽚
 =======================================================================================*/
void TaskE(){
    PROCESS* process= &proc_table[4];

    while (1){
//        color=1;
//        myPrint("Ework! ");
        switch (strategy) {
            case 0:
                rf_writer(process);
                break;
            case 1:
                wf_writer(process);
                break;
            case 2:
                fair_writer(process);
                break;
        }

    }
}

/*=======================================================================================
 *                        new add Task F writer 消耗4个时间⽚
 =======================================================================================*/
void TaskF(){
    PROCESS* process= &proc_table[5];

    while (1){
//        color=1;
//        myPrint("Fwork! ");
        switch (strategy) {
            case 0:
                rf_writer(process);
                break;
            case 1:
                wf_writer(process);
                break;
            case 2:
                fair_writer(process);
                break;
        }

    }
}