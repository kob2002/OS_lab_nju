
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                               proc.c
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                                                    Forrest Yu, 2005
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include "type.h"
#include "const.h"
#include "protect.h"
#include "proto.h"
#include "string.h"
#include "proc.h"
#include "global.h"

int count=0;
int last=1;
int judge=0;
PROCESS* lastPro=proc_table;
/*============================================================================
 *  把数字变为char数组
 =============================================================================*/

char* transIntToCharArr(int x,char content[10]){
    content[0]='\0';
    int index=0;
    if(x<0){
        content[index++]='-';
        x=-x;
    }
    if(x<10){
        content[index++]=x+'0';
        content[index++]='\0';
    }else{
        content[index++]='!';
        content[index++]='\0';
    }
    return content;
}

void printCurrent(){
    color=1;
    char content[10];
    for(int i=1;i<6;i++){
        myPrint(transIntToCharArr(i,content));
        myPrint(":");
        myPrint(transIntToCharArr(proc_table[i].workTimeLeft,content));
        myPrint(" ");
        myPrint(transIntToCharArr(proc_table[i].sleepTimeLeft,content));
        myPrint(" ");
    }
    myPrint("\n");
}

/*======================================================================
 *         判断是否可以打印
 =====================================================================*/
int isReady(){
    for(int i=0;i<5;i++){
        if(isReadyToPrint[i]==0) return 0;
    }
    return 1;
}
void resetReady(){
    for(int i=0;i<5;i++) isReadyToPrint[i]=0;
}
/*======================================================================*
                              schedule
 *======================================================================*/

/* proc.c */
//通过p_proc_ready传递给外界信息，出循环时p_proc_ready已经是可执行的第一个进程了
PUBLIC void schedule()
{

    //disp_str("A");
    disable_irq(CLOCK_IRQ);
    //printCurrent();
    char content[10];
    PROCESS* p; // 修改此结构体
    int current_tick = get_ticks();
    if(judge%2==0){ //A进程的优先级最高 如果A可以打印 则一定打印A
        //每隔一次就要打印一次
        //disp_str("B");

        p_proc_ready=proc_table;
        //resetReady();

    }else{
        //disp_str("time fly");

        int counter=0;
        p_proc_ready=proc_table+last;//先置为taskB
        while (1) {
            if(counter>6){
                //disp_str("!");
                //说明已经循环一轮了，没有可以拿出来的进程 则要调用打印进程,同时推进时间片
                p_proc_ready=proc_table;//该轮次只推进时间 然后进入打印 但不增加judge 这样下一轮还是进入这个
                judge--;
                break;
            }

            //disp_str(p_proc_ready->p_name);
            //disp_str("!");
//            disp_str(transIntToCharArr(p_proc_ready->sleepTimeLeft));
//            disp_str(" ");
            if (p_proc_ready >= proc_table + NR_TASKS) { //proc_table 进程表
                p_proc_ready = proc_table+1;
            }//如果到表尾了，则要回到表头的下一个 即进程B（避开进程A）
            if (p_proc_ready->blocked ==0 && p_proc_ready->sleepTimeLeft <= 0&&p_proc_ready->workTimeLeft<=0) { //进程未被堵塞也未睡眠也未工作
                //disp_str(p_proc_ready->p_name);
                break; // 寻找到进程
            }
            counter++;
            p_proc_ready++;
        }
        last=p_proc_ready-proc_table;
    }
    judge++;
    enable_irq(CLOCK_IRQ);
}

/*PUBLIC void schedule()
{
    disable_irq(CLOCK_IRQ);
    //disp_str("!");
    PROCESS* p; // 修改此结构体
    if(judge==0){
        //第一轮 必须打印A
        p_proc_ready=proc_table;
        judge++;

    }else{
        //非首轮
        if(isReady()==1){
            p_proc_ready=proc_table;
            resetReady();
            lastPro=proc_table;
            //时间片的推进在进程A中
        }else{
            //获得该阶段应该调用的进程
            lastPro++;
            int flag=0;
            for(;lastPro<proc_table + NR_TASKS;lastPro++){

                //逐一筛查五个进程是否能够在本轮执行（这五次调用都算入同一时间片中）
                //能跑则跑 不能跑则置ready位为1
                if (lastPro->blocked ==0 && lastPro->sleepTimeLeft <= 0&&lastPro->workTimeLeft<=0) { //进程未被堵塞也未睡眠也未工作
                    isReadyToPrint[lastPro-proc_table-1]=1;
                    flag=1;
                    //disp_str(lastPro->p_name);
                    break; // 寻找到进程 准备调用该进程
                }else{
                    isReadyToPrint[lastPro-proc_table-1]=1;
                }
            }

            if(flag==0){

               *//* p_proc_ready=proc_table;
                lastPro=proc_table;//重置*//*
               // disp_str("=");
               schedule();
            }else{
                p_proc_ready=lastPro;
            }

        }
    }

    judge++;
    // enable_irq(CLOCK_IRQ);
}*/

/*======================================================================*
                           sys_get_ticks  这里的名字和global.c对应上即可
 *======================================================================*/
PUBLIC int sys_get_ticks()
{
	return ticks;
}

/*===================================================================
 *                 new add :sleep 时间片公式
 *
 ===================================================================*/
PUBLIC void sys_sleep(int milliseconds) { //让当前的进程的醒来时间改变 并重新调度新的进程
    p_proc_ready->sleepTimeLeft = milliseconds / TIME_SLICE;
    //disp_str("block=");
    schedule();
}

/*====================================================================
 *                 new add :sys_print
 *调用内核中写好的void disp_color_str(char * info, int color);和void disp_str(char * info); （/lib/kliba.asm）
 ====================================================================*/

PUBLIC void sys_print(char*s){
    switch (color) {
        case 1:
            disp_color_str(s,BRIGHT | MAKE_COLOR(BLACK, WHITE));
            break;
        case 4:
            disp_color_str(s,BRIGHT | MAKE_COLOR(BLACK, GREEN));
            break;
        case 2:
            disp_color_str(s,BRIGHT | MAKE_COLOR(BLACK, BLUE));
            break;
        case 3:
            disp_color_str(s,BRIGHT | MAKE_COLOR(BLACK, RED));
            break;
        default:
            disp_color_str(s,BRIGHT | MAKE_COLOR(BLACK, RED));
            break;
    }


}



/*=========================================================================
 *              new add :sys_p 系统调用 P定义在syscall中
 =========================================================================*/
PUBLIC void sys_p(void* mutex){
    disable_irq(CLOCK_IRQ); //保证P不可被中断
    Semaphore *semaphore = (Semaphore *)mutex;
    //char content[10];
//    myPrint("[");
//    myPrint(transIntToCharArr(semaphore->value,content));
//    myPrint("] ");
    (semaphore->value)--;
    if(semaphore->value<0){
        p_proc_ready->blocked=1;//阻塞当前进程 并把当前进程放至队尾
        semaphore->tail=(semaphore->tail+1)%NR_TASKS;//将队尾后移一个（循环队列)
        (semaphore->queue)[semaphore->tail]=p_proc_ready;
        //disp_str("block=");
        schedule();  //找到新的p_proc_ready
    }

    enable_irq(CLOCK_IRQ);
}

PUBLIC void sys_v(void* mutex){
    disable_irq(CLOCK_IRQ); //保证P不可被中断
    Semaphore *semaphore = (Semaphore *)mutex;
    (semaphore->value)++;
    if(semaphore->value<=0){
        //说明在释放资源之前队列里有人在等 所以释放的这个资源需要唤醒队列里的第一位
        //disp_str("");
        int m=semaphore->head;
        (semaphore->queue)[m]->blocked=0;// 打开队列中的第一位
        semaphore->head=(semaphore->head+1)%NR_TASKS;//将队首后移一个（出队）

    }
    enable_irq(CLOCK_IRQ);
}